import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-resultats-recherche',
  templateUrl: './resultats-recherche.component.html',
  styleUrls: [
    './jquery-ui-themes.css',
    './axure_rp_page.css',
    './styles_data.css',
    './styles_resultat_recher.css'
]
})
export class ResultatsRechercheComponent implements OnInit {

  @Input() niveau: string;
  @Input() sujet: string;
  @Input() exercice: string;

  constructor() { }

  ngOnInit() {
  }

}
